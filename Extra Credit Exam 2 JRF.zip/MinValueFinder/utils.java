//For Min # program
public class utils {
    public static int min(int a, int b, int c) {
        int min = a; // Assume a is the smallest initially
        if (b < min) {
            min = b; // Update min if b is smaller
        }
        if (c < min) {
            min = c; // Update min if c is smaller
        }
        return min; // Return the smallest value
    }
}
