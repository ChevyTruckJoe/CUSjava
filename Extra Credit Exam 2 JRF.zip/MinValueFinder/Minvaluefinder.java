public class Minvaluefinder {
    public static void main(String[] args) {
        int a = 10;
        int b = 5;
        int c = 7;
        int result = utils.min(a, b, c);
        System.out.println("The minimum value is: " + result);
    }

    
}