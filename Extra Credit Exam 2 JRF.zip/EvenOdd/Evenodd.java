public class Evenodd{
    public static void main(String[] args) {
    int number = 4; // Example number
        boolean result = utils.isEven(number);
        System.out.println("Is " + number + " even? :" + result);
    }}