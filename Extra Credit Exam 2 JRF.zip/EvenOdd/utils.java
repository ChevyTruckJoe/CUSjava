//For even/odd program

public class utils {
    public static boolean isEven(int number) {
        return number % 2 == 0;
    }
}